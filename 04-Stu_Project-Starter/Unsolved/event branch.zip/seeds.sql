INSERT INTO events (venue, theme, date_time, specials, address, neighborhood, food_type)
VALUES ("Golf & Social", "Brunch & Boozy", "2019-05-12:12:00", "Bottomless Brunch, Day Party, Food", "1080 N. Delaware Ave, Philadelphia, PA 19125", "Fishtown", "American" );
INSERT INTO events (venue, theme, date_time, specials, address, neighborhood, food_type)
VALUES ("Creperie Beau Monde & L'Etage", "Burlesque Brunch", "2019-06-23:12:30", "Burlesque, Drinks, Food", "624 S. 6th St, Philadelphia, PA 19147", "Queen Village", "French" );
INSERT INTO events (venue, theme, date_time, specials, address, neighborhood, food_type)
VALUES ("Circle of Hope", "The Brand Brunch", "2019-05-15:12:00", "Networking, Drinks", "1122 S. Broad St, 3rd Flr, Philadelphia, PA 19147", "Queen Village", "None" );